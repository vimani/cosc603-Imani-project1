/**
 * 
 */

/**
 * @author omololu
 *
 */
public class FireDangerRatingSystem {

	/**
	 * 
	 */
	public FireDangerRatingSystem() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
