/**
 * 
 */

/**
 * @author omololu
 *
 */
public class Process {

	/**
	 * 
	 */
	public Process() {
		// TODO Auto-generated constructor stub
	}

}
