/**
 * 
 */

public class Subroutine {

	private double dryFactor =0;
	//Dry Bulb Temperature
	private double dry;
	//Wet Bulb Temperature
	private double wet;
	//The current wind speed in miles per hour
	private double wind;
	//The past 24 hours precipitation
	private static double precip;
	//Yesterdays Buildup
	private static double bUOIndex;
	//The current fine fuel moisture
	private static double fineFuelMoist = 99;
	private static double adjustedFuelMoisture = 99;
	private static double fireLoadRating =0;
	//The last value of the Build Up Index Recovery
	private static double bUIndex;
	//Grass spread index
	private static double gRassIndex;
	//Timber spread index
	private static double tImberIndex;
	//Table Dimension values used in computing the danger ratings
	private double[] A = new double [4];
	private double[] B = new double [4];
	private double[] C = new double [3];
	private double[] D = new double [6];
	
	public Subroutine() {
		//Initialize Dimensions
		A[1] = -0.185900;
		A[2] = -0.85900;
		A[3] = -0.059660;
		A[4] = 0.077373;
		B[1] = 30.0;
		B[2] = 19.2;
		B[3] = 13.8;
		B[4] = 22.5;
		C[1] = 4.5;
		C[2] = 12.5;
		C[3] = 27.5;
		D[1] = 16.0;
		D[2] = 10.0;
		D[3] = 7.0;
		D[4] = 5.0;
		D[5] = 4.0;
		D[6] = 3.0;
		
	}
	
	// Check Snow Level
	public boolean isSnow(){
		return false;
	}
	
	// Check Rain Level
	public boolean isRain(){
		return false;
	}
	
	// Calculate Fine Fuel Moisture
	public double calcFineFuelMoisture(int stage){
		fineFuelMoist = A * Math.exp(B) * (dry-wet);
	}
	
	//Adjust
	public static void adjustBUI(){
		bUIndex = -50*(Math.log(Math.exp(1-(-Math.exp(bUOIndex/50)))))*Math.exp(1.175*(precip - 0.1));
	}
	
	public static void calcAdjustedFuelMoisture(){
		adjustedFuelMoisture = (0.9*(fineFuelMoist)) + (9.5 * Math.exp(-bUIndex/50));
	}
	
	public double calcDryFactor(){
		return 0;
	}
	
	public double calcGrassSpreadIndex(){
		gRassIndex = A*(wind + B) * (Math.pow((33 - fineFuelMoist), 1.65) -3);
	}
	
	public double calcTimberSpreadIndex(){
		tImberIndex = A*(wind + B) * (Math.pow((33 - fineFuelMoist), 1.65) -3);
	}
	
	public static void calcFireLoadIndex(){
		fireLoadRating = Math.pow(10, 1.75 * (Math.log10(tImberIndex) + 32 *(Math.log10(bUIndex) - 1.64)));
	}

}
